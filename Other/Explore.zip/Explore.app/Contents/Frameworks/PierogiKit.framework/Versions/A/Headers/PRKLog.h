//
//  PRKLog.h
//  PierogiKit
//
//  Created by Vashishtha Jogi on 7/21/17.
//  Copyright © 2017 Apple Inc. All rights reserved.
//

#define PRKLOG_MACRO(lvl, frmt, ...) \
    NSString *message = [[NSString alloc] initWithFormat:frmt, ##__VA_ARGS__]; \
    [Pierogi logWithLevel:lvl message:message function:[NSString stringWithUTF8String:__PRETTY_FUNCTION__] filePath:[NSString stringWithUTF8String:__FILE__] fileLine:__LINE__];

#define PRKLogError(format, ...)    PRKLOG_MACRO(PRKLogLevelError, format, ##__VA_ARGS__)
#define PRKLogWarn(format, ...)     PRKLOG_MACRO(PRKLogLevelWarning, format, ##__VA_ARGS__)
#define PRKLogInfo(format, ...)     PRKLOG_MACRO(PRKLogLevelInfo, format, ##__VA_ARGS__)
#define PRKLogDebug(format, ...)    PRKLOG_MACRO(PRKLogLevelDebug, format, ##__VA_ARGS__)
#define PRKLogTrace(format, ...)    PRKLOG_MACRO(PRKLogLevelTrace, format, ##__VA_ARGS__)
