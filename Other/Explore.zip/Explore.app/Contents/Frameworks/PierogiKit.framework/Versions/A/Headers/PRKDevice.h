//
//  PRKUtilities.h
//  PirogiKitCore
//
//  Created by Vashishtha Jogi on 6/26/17.
//  Copyright © 2017 Apple Inc. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_SWIFT_NAME(Device)
@interface PRKDevice : NSObject

+ (instancetype)sharedManager;

/*!
 @method        primaryIPV4Address
 @abstract      returns the first IPV4 address assigned to this device, or nil
 */
+ (NSString*)primaryIPV4Address;

/*!
 @method        primaryIPV6Address
 @abstract      returns the first IPV6 address assigned to this device, or nil
 */
+ (NSString*)primaryIPV6Address;

/**
 *  Serial number of the device
 *
 *  @return returns a string which is the serial number of the device
 */
+ (NSString *)serialNumber;

/**
 * @return    returns the product name of the device
 */
+ (NSString *)productName;

/**
 * @return    returns the product type of the device. Eg. iPhone7_1
 */
+ (NSString *)productType;

/**
 * @return    returns the device type of the device. Eg. iPhone, iPad, etc.
 */
+ (NSString *)deviceType;

#if TARGET_OS_IPHONE
/**
 * @return    returns the device device model number. Eg. MG456LL/A
 */
+ (NSString *)modelNumber;

/**
 * @return    returns if the device is iPhoneX
 */
+ (BOOL)isIPhoneXOrAbove;
#endif

/**
 * @return    returns the mac address of the devices
 */
+ (NSString *)macAddress;

/**
 *  Get the current connected WIFI SSID
 *
 *  @return returns the name of the wifi network if connected to any
 */
+ (NSString *)wifiSSID;

/**
 *  Returns the current wifi rssi strength
 *
 *  @return wifi rssi strength
 */
+ (NSNumber *)wifiRSSI;

@end
