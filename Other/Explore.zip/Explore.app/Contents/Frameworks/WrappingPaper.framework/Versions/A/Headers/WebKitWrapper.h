//
//  WebKitWrapper.h
//  WrappingPaper
//
//  Created by Isaac Wankerl on 2/24/21.
//  Copyright © 2021 Apple Inc. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <WebKit/WebKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface WebKitWrapper : NSObject

+ (void)configurePreferences:(WKPreferences *)preferences asDebug:(BOOL)asDebug;

#if TARGET_OS_IPHONE

+ (void)setWebView:(WKWebView *)webView dragInteractionPolicyAlwaysDisabled:(BOOL)alwaysDisabled;
+ (WKProcessPool *)processPoolWithSingleWebProcess;

#else

+ (void)setupWebViewAppearance:(WKWebView *)webView;

#endif

@end

NS_ASSUME_NONNULL_END
