//
//  DemodManager.h
//  WrappingPaper
//
//  Created by Isaac Wankerl on 3/27/20.
//  Copyright © 2020 Apple Inc. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

typedef void (^DemodResponse)(BOOL result, NSError * _Nullable error);


@protocol DemodInterface <NSObject>

// last frozen state
@property (nonatomic, assign, readonly) BOOL isFrozen;

// is device enrolled into iOSdm
@property (nonatomic, assign, readonly) BOOL isManaged;

- (void)wakeDemod;

#if TARGET_OS_IPHONE
- (void)freezeWithCompletionBlock:(DemodResponse)completionBlock;
- (void)unfreezeWithCompletionBlock:(DemodResponse)completionBlock;
#endif

- (void)sendUpdateRequest:(DemodResponse)completionBlock;
- (void)sendUpdateCompleteRequest:(DemodResponse)completionBlock;
- (void)startSendingHeartbeat;
- (void)validateHeartbeat;

- (NSString * _Nullable)getAppDataFolderPathWithReturnError:(NSError * _Nullable * _Nullable)error;
- (BOOL)preserveAppDataToPersistentStorageWithReturnError:(NSError * _Nullable * _Nullable)error;

@end


@protocol DemodLogging <NSObject>

- (void)logDebugWithFormat:(NSString *)format, ... NS_FORMAT_FUNCTION(1,2);
- (void)logErrorWithFormat:(NSString *)format, ... NS_FORMAT_FUNCTION(1,2);
- (void)logSystemEventWithName:(NSString *)name attributes:(NSDictionary *)attributes;

@end


#if TARGET_OS_IPHONE
@interface DemodManager : NSObject <DemodInterface>

- (instancetype)initWithFreezingFeature:(BOOL)shouldFreezeUnfreeze loggingHelper:(id<DemodLogging>)loggingHelper;

- (instancetype)init NS_UNAVAILABLE;

@end
#endif

NS_ASSUME_NONNULL_END
