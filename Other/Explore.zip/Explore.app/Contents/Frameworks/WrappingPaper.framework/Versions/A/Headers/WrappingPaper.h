//
//  WrappingPaper.h
//  WrappingPaper
//
//  Created by Isaac Wankerl on 2/21/20.
//  Copyright © 2020 Apple Inc. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for WrappingPaper.
FOUNDATION_EXPORT double WrappingPaperVersionNumber;

//! Project version string for WrappingPaper.
FOUNDATION_EXPORT const unsigned char WrappingPaperVersionString[];

#import <WrappingPaper/DemodManager.h>
#import <WrappingPaper/WebKitWrapper.h>

#if TARGET_OS_IPHONE
// iOS specific headers
#import <WrappingPaper/MobileGestaltWrapper.h>
#import <WrappingPaper/UIApplicationWrapper.h>

#elif TARGET_OS_MAC
// macOS specific headers
#import <WrappingPaper/UniversalAccessWrapper.h>

#endif
