//
//  UniversalAccessWrapper.h
//  WrappingPaper macOS
//
//  Created by Isaac Wankerl on 3/6/20.
//  Copyright © 2020 Apple Inc. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface UniversalAccessWrapper : NSObject

+ (BOOL)isVoiceOverEnabled;

+ (void)setVoiceOverEnabled:(BOOL)enabled;

+ (BOOL)isVoiceOverRunning;

@end

NS_ASSUME_NONNULL_END
