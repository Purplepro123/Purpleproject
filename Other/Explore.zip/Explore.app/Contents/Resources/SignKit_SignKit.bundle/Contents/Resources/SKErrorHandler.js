//
//  SKErrorHandler.js
//
//
//  Created by Rubén Santiago on 6/29/23.
//

// Save a copy of the original console before overriding it
const _console = console;

// SignKit MessageHandler must be named `SKErrorHandler` for this function to work.
function sendMessageToSignKit(msg) {
    //  _console.debug.apply(console, ['Posting message to SignKit: ' + msg]);
    window.webkit.messageHandlers.SKErrorHandler.postMessage(msg);
}

window.console = {
    log: function(msg) {
        _console.log.apply(console, [msg]);
        sendMessageToSignKit('LOG: ' + msg);
    },
    info: function(msg) {
        _console.info.apply(console, [msg]);
        sendMessageToSignKit('INFO: ' + msg);
    },
    warn: function(msg) {
        _console.warn.apply(console, [msg]);
        sendMessageToSignKit('WARN: ' + msg);
    },
    debug: function(msg) {
        _console.debug.apply(console, [msg]);
        sendMessageToSignKit('DEBUG: ' + msg);
    },
    trace: function(msg) {
        _console.trace.apply(console, [msg]);
        sendMessageToSignKit('TRACE: ' + msg);
    },
    error: function(msg) {
        _console.error.apply(console, [msg]);
        sendMessageToSignKit('ERROR: ' + msg);
    }
}

// Uncaught exceptions handler
window.onerror = function (message, source, line, column, error) {
    _console.error.apply(console, ['Uncaught Exception: ${error}']);
    console.error('Uncaught Exception:', error);
};

// Rejected promises handler
window.addEventListener('unhandledrejection', function (event) {
    _console.error.apply(console, ['Unhandled Promise Rejection: ${event.reason}']);
    console.error('Unhandled Promise Rejection:', event.reason);
});
